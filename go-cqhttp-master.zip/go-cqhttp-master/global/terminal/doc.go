// Package terminal 包含用于检测在windows下是否通过双击运行go-cqhttp的函数
package terminal
