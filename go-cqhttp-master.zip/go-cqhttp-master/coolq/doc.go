// Package coolq 包含CQBot实例,CQ码处理,消息发送,消息处理等的相关函数与结构体
package coolq
