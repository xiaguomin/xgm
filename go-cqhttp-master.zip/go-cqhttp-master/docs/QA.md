# 常见问题

> 注意, 最新文档已经移动到 [go-cqhttp-docs](https://github.com/ishkong/go-cqhttp-docs), 当前文档只做兼容性保留, 所以内容可能有不足.

### Q: 为什么挂一段时间后就会出现 `消息发送失败，账号可能被风控`?

### A: 如果你刚开始使用 go-cqhttp 建议挂机3-7天，即可解除风控
